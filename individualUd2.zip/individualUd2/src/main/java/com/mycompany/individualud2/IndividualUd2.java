/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.individualud2;

/**
 *
 * @author Chema
 */
public class IndividualUd2 {



public class Main {
    public static void main(String[] args) {
    // Comprueba si se han pasado los argumentos necesarios
    if (args.length < 2) {
        System.out.println("Por favor, introduce el número de productores y consumidores como argumentos.");
        System.out.println("Uso: java TuClase <numProductores> <numConsumidores>");
        return;
    }

    // Intenta convertir los argumentos a enteros
    int numProductores, numConsumidores;
    try {
        numProductores = Integer.parseInt(args[0]);
        numConsumidores = Integer.parseInt(args[1]);
    } catch (NumberFormatException e) {
        System.out.println("Los argumentos deben ser números enteros.");
        return;
    }

        Bfer bfer;
        bfer = new Bfer();
        
        for (int i = 0; i < numProductores; i++) {
            new Productor(bfer).start();
        }
        
        for (int i = 0; i < numConsumidores; i++) {
            new Consumidor(bfer).start();
        }
    }
}
}
