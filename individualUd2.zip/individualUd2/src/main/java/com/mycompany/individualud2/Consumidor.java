/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.individualud2;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Chema
 */

class Consumidor extends Thread {
    private Bfer bfer;
    private Random random = new Random();

    public Consumidor(Bfer bfer) {
        this.bfer = bfer;
    }

    public void run() {
        while (true) {
            int item = bfer.get();
            System.out.println("Consumidor " + Thread.currentThread().getId() + " consumió: " + item);
            processItem(item);
            try {
                Thread.sleep(random.nextInt(1000)); // Simula tiempo de consumo
            } catch (InterruptedException ex) {
                Logger.getLogger(IndividualUd2.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private void processItem(int item) {
        // Simula el procesamiento del ítem
        // Por ejemplo, puedes realizar alguna operación o simplemente hacer una pausa
    }
}
