/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.individualud2;

import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author Chema
 */
class Bfer {
    private Queue<Integer> queue = new LinkedList<>();
    private final int LIMIT = 10;

    public synchronized void put(int value) {
        while (queue.size() == LIMIT) {
            try {
                wait();
            } catch (InterruptedException e) { }
        }
        queue.add(value);
        notifyAll();
    }

    public synchronized int get() {
        while (queue.isEmpty()) {
            try {
                wait();
            } catch (InterruptedException e) { }
        }
        int value = queue.poll();
        notifyAll();
        return value;
    }
}
