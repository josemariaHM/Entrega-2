/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.individualud2;

/**
 *
 * @author Chema
 */
class Productor extends Thread {
    private Bfer bfer;

    public Productor(Bfer bfer) {
        this.bfer = bfer;
    }

    public void run() {
        while (true) {
            int item = produceItem();
            bfer.put(item);
            System.out.println("Productor " + Thread.currentThread().getId() + " produjo: " + item);
            try {
                // Fijamos un tiempo de espera de 1 segundo (1000 milisegundos).
                Thread.sleep(1000); 
            } catch (InterruptedException e) {
                // En un caso real, deberías manejar esta excepción adecuadamente.
                e.printStackTrace();
            }
        }
    }
    

    private int produceItem() {
        // Simula la producción de un ítem. Aquí simplemente incrementamos un contador.
        // Si necesitas que el ítem sea único o siga alguna secuencia, puedes implementar esa lógica aquí.
        return (int) (Math.random() * 100);
    }
}
